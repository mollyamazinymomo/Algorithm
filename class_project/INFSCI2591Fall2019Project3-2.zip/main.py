
graph1=[[0,4,0,2,1],
        [4,0,1,3,5],
        [0,1,0,3,0],
        [2,3,3,0,2],
        [1,5,0,2,0]]

graph2=[[0,3,2,0,0,4],
        [3,0,1,1,0,1],
        [2,1,0,4,5,0],
        [0,1,4,0,2,0],
        [0,0,5,2,0,2],
        [4,1,0,0,2,0]]

class Graph(): 
	def __init__(self,graph):
		self.graph=graph
		self.V=len(graph)
		self.all_path=[]
		self.total_weight=float("inf")
		self.circle=None
	
	def isSafe(self, v,pos,path):
		if self.graph[path[pos-1] ][v]==0:
			return False

		for vertex in path: 
			if vertex == v: 
				return False

		return True

	def hamCycleUtil(self, path, pos): 

		if pos == self.V: 
			if self.graph[ path[pos-1] ][ path[0] ] == 1:
				self.all_path.append(list(path))
				if sum(path)<self.total_weight:
					self.total_weight=sum(path)
					self.circle=list(path)
				return True
			else: 
				return False

		for v in range(1,self.V): 
			if self.isSafe(v, pos, path) == True: 
				path[pos] = v 
				self.hamCycleUtil(path, pos+1)
				path[pos] = -1

		return False

	def hamCycle(self): 
		path = [-1] * self.V 

		path[0] = 0

		self.hamCycleUtil(path,1)

		self.printSolution() 

	def printSolution(self): 
		if self.all_path==[]:
			print("Solution does not exist\n")
		else:
			print ("Solution Exists: Following is all the Hamiltonian Cycle")
			for path in self.all_path: 
				print (path)
			print("")
			print("The minimum weight is",self.total_weight)
			print("The path with minimum weight is",self.circle)


g1 = Graph(graph1) 
g1.hamCycle()

print("")
g2 = Graph(graph2) 
g2.hamCycle()




