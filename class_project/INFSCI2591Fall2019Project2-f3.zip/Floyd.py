def Floyd(graph):
  cost=graph
  n=len(graph)
  pre=[[0 for i in range(n)]for i in range(n)]
  for i in range(n):
    for j in range(n):
      pre[i][j]=i
  
  for t in cost:
    for i in cost:
      if i !=t:
        for j in cost[i]:
          if j !=t:
              if cost[i][j]>cost[i][t]+cost[t][j]:
                cost[i][j]=cost[i][t]+cost[t][j]
                pre[i][j]=pre[t][j]
  
  return cost,pre