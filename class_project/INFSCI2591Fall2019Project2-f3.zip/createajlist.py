import random

class Vertex:
  def __init__(self,key):
    self.v_id=key
    self.connectedTo={}

  def addneighbor(self,neigh_id,weight):
    self.connectedTo[neigh_id]=weight
  
  def __side__(self):
    return str(self.v_id)+'connected to:'+str([x.id for x in self.connectedTo])
  
  def getConnections(self):
    return self.connectedTo.keys()

  def getId(self):
    return self.v_id

  def getWeight(self,neigh_id):
    return self.connectedTo[neigh_id]

class Graph:
  def __init__(self):
    self.vertlist={}
    self.numVertics=0
  
  def addVertex(self,key):
    self.numVertics +=1
    newVertex=Vertex(key)
    self.vertlist[key]=newVertex
    return newVertex

  def getVertex(self,n):
    if n in self.verlist:
      return self.verlist[n]
    else: 
      return None

  def addEdge(self,first,tail,weight):
    self.vertlist[first].addneighbor(self.vertlist[tail],weight)

  def getVertics(self):
    return self.vertlist.keys()

  def __iter__(self):
    return iter(self.vertlist.values())

def Create_complete_ajlist(n):
  g=Graph()
  graph={}
  for i in range(n):
    g.addVertex(i)

  for i in range(n):
    for j in range(i,n):
      if i==j:
        g.addEdge(i,j,0)
      else:
        weight=random.randint(1,1000)
        g.addEdge(i,j,weight)
        g.addEdge(j,i,weight)
  
  for v in g:
    graph[v.getId()]={w.getId():v.getWeight(w) for w in v.getConnections() if w.getId() != v.getId()}

  return graph

# cannot get the graph by this way, understand more about the class and consider how to return the graph


def Create_sparse_ajlist(n):
  g=Graph()
  graph={}
  for i in range(n):
    g.addVertex(i)

  for i in range(n):
    for j in range(i,n):
      if i==j:
        g.addEdge(i,j,0)
      else:
        g.addEdge(i,j,float("inf"))
        g.addEdge(j,i,float("inf"))
  
  for i in range(n-1):
    weight=random.randint(1,1000)
    tail=0
    tail=random.randint(i+1,n-1)
    g.addEdge(i,tail,weight)
    g.addEdge(tail,i,weight)

  for v in g:
    graph[v.getId()]={w.getId():v.getWeight(w) for w in v.getConnections() if w.getId() != v.getId()}
  
  return graph
  

