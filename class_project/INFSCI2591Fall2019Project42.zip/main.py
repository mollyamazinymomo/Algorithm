import random
import time
import matplotlib.pyplot as plt
import numpy as np

def kthsmallest1(arr,l,r,k):
	if k>0 and k<=r-l+1:
		pos=partition1(arr,l,r)
		if pos-l==k-1:
			return arr[pos]
		elif pos-l>k-1:
			return kthsmallest1(arr,l,pos-1,k)
		return kthsmallest1(arr,pos+1,r,k-pos+l-1)
	return -1

def partition1(arr,l,r):
	x=arr[r]
	i=l
	for j in range(l,r):
		if arr[j]<=x:
			arr[i],arr[j]=arr[j],arr[i]
			i+=1
	arr[i],arr[r]=arr[r],arr[i]
	return i

def kthsmallest2(arr,l,r,k):
	if k>0 and k<=r-l+1:
		n=r-l+1
		median=[]
		i=0
		while i<n//5:
			median.append(findMedian(arr, l + i * 5, 5))
			i+=1
		if i*5<n:
			median.append(findMedian(arr, l + i * 5, n%5))
			i+=1
		if i==1:
			medOfMed=median[i-1]
		else:
			medOfMed=kthsmallest2(median,0,i-1,i//2)
		
		pos=partition2(arr,l,r,medOfMed)
		if pos-l==k-1:
			return arr[pos]
		elif pos-l>k-1:
			return kthsmallest2(arr,l,pos-1,k)
		
		return kthsmallest2(arr,pos+1,r,k-pos+l-1)

	return -1

def partition2(arr,l,r,x):
	for i in range(l,r):
		if arr[i]==x:
			arr[r],arr[i]=arr[i],arr[r]
			break
		
	x=arr[r]
	i=l
	for j in range(l,r):
		if arr[j]<=x:
			arr[i],arr[j]=arr[j],arr[i]
			i+=1
	
	arr[i],arr[r]=arr[r],arr[i]
	return i

def findMedian(arr,l,n):
	list1=[]
	for i in range(l,l+n):
		list1.append(arr[i])
	
	list1.sort()
	return list1[n//2]

def kthsmallest3(arr,l,r,k):
	return kthsmallest3_helper(arr,l,r,k-1)

def kthsmallest3_helper(arr,l,r,k):
	if l==r:
		return arr[l]
	else:
		pivotpoint=partition3(arr,l,r)
		if k==pivotpoint:
			return arr[pivotpoint]
		elif k<pivotpoint:
			return kthsmallest3_helper(arr,l,pivotpoint-1,k)
		else:
			return kthsmallest3_helper(arr,pivotpoint+1,r,k)

def partition3(arr,l,r):
	randomspot=random.randint(l,r)
	arr[l],arr[randomspot]=arr[randomspot],arr[l]
	pivotitem=arr[l]
	j=l
	for i in range(l+1,r+1):
		if arr[i]<pivotitem:
			j+=1
			arr[i],arr[j]=arr[j],arr[i]

	pivotpoint=j
	arr[l],arr[pivotpoint]=arr[pivotpoint],arr[l]
	return pivotpoint


##Test##
# choice=input("See QuickSelect working case:\n1.Worst Case\n2.Best Case\n3.Average Case\n\nSee Selection use Median work case:\n4.Worst Case\n5.Best Case\n6.Average Case\n\nSee Probabilistic Selection work case:\n7.Worst Case\n8.Best Case\n9.Average Case\n\nYour choice: ")
# choice=int(choice)

# n=1000
# arr=random.sample(range(1,n+1),n)
# print(arr)

##Quick select worst case: when array sort increasing order and k=n
def testing(choice,n,arr):
	if choice==1:
		arr.sort()
		k=len(arr)
		start=time.time()
		print('The kth smallest number is',kthsmallest1(arr,0,n-1,k))
		end=time.time()
		time_used=round(end-start,9)
		print('Use Time:',time_used)
		return time_used

	##QuickSelect best case
	if choice==2:
		k=1
		start=time.time()
		print('The kth smallest number is',kthsmallest1(arr,0,n-1,k))
		end=time.time()
		time_used=round(end-start,9)
		print('Use Time:',time_used)
		return time_used

	##QuickSelect average case
	if choice==3:
		timelist=[]
		for i in range(1,n+1,10):
			start=time.time()
			kthsmallest1(arr,0,n-1,i)
			end=time.time()
			time_used=round(end-start,9)
			timelist.append(time_used)
		
		meantime=sum(timelist)/len(timelist)
		print('Average Time Use:',meantime)
		return meantime

	#Selecing with Median worst case
	if choice==4:
		k=len(arr)
		start=time.time()
		print('The kth smallest number is',kthsmallest2(arr,0,n-1,k))
		end=time.time()
		time_used=round(end-start,9)
		print('Use Time:',time_used)
		return time_used
		
	##Selecting with Median best case
	if choice==5:
		k=1
		start=time.time()
		print('The kth smallest number is',kthsmallest2(arr,0,n-1,k))
		end=time.time()
		time_used=round(end-start,9)
		print('Use Time:',time_used)
		return time_used

	##Selecting with Median average case	
	if choice==6:
		timelist=[]
		for i in range(1,n+1,10):
			start=time.time()
			kthsmallest2(arr,0,n-1,i)
			end=time.time()
			time_used=round(end-start,9)
			timelist.append(time_used)
		
		meantime=sum(timelist)/len(timelist)
		print('Average Time Use:',meantime)
		return meantime

	## Probabilistic selection worst case
	if choice==7:
		k=len(arr)
		start=time.time()
		print('The kth smallest number is',kthsmallest3(arr,0,n-1,k))
		end=time.time()
		time_used=round(end-start,9)
		print('Use Time:',time_used)
		return time_used

	## Probabilistic selection best case
	if choice==8:
		k=1
		start=time.time()
		print('The kth smallest number is',kthsmallest3(arr,0,n-1,k))
		end=time.time()
		time_used=round(end-start,9)
		print('Use Time:',time_used)
		return time_used

	## Probabilistic selection average case
	if choice==9:
		timelist=[]
		for i in range(1,n+1,10):
			start=time.time()
			kthsmallest3(arr,0,n-1,i)
			end=time.time()
			time_used=round(end-start,9)
			timelist.append(time_used)
		
		meantime=sum(timelist)/len(timelist)
		print('Average Time Use:',meantime)
		return meantime

	
timeall=[]
for i in range(1,10):
	choice=i
	for j in range(100,700,100):
		n=j
		arr=random.sample(range(600),n)
		time_used=testing(choice,n,arr)
		timeall.append(time_used)


x=[100,200,300,400,500,600]
timearray=np.array(timeall).reshape(9,6)
print(timearray)

##Draw plot
figure=plt.figure(num=3, figsize=(15, 8),dpi=80)
ax1 = figure.add_subplot(221)  
ax2 = figure.add_subplot(222)
ax3 = figure.add_subplot(223)
ax1.plot(x,timearray[0],label='Worst Case')
ax1.plot(x,timearray[1],label='Best Case')
ax1.plot(x,timearray[2],label='Average Case')
ax1.legend(title='Time Complexity Analysis')
ax1.set_title("QuickSelection")
ax1.set_ylabel("Time/s")
ax1.set_xlabel("Numbers")

ax2.plot(x,timearray[3],label='Worst Case')
ax2.plot(x,timearray[4],label='Best Case')
ax2.plot(x,timearray[5],label='Average Case')
ax2.legend(title='Time Complexity Analysis')
ax2.set_title("SelectByMedian")
ax2.set_ylabel("Time/s")
ax2.set_xlabel("Numbers")

ax3.plot(x,timearray[6],label='Worst Case')
ax3.plot(x,timearray[7],label='Best Case')
ax3.plot(x,timearray[8],label='Average Case')
ax3.legend(title='Time Complexity Analysis')
ax3.set_title("ProbabilisticSelection")
ax3.set_ylabel("Time/s")
ax3.set_xlabel("Numbers")

plt.savefig("SelectionAlgorithmComparision.png")








	

