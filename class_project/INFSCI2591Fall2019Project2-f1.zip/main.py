from create1dmatrix import *
from Floyd import *
from test import *
import time
import os 
import psutil

def show_memory_info(hint):
    pid = os.getpid()
    p = psutil.Process(pid)

    info = p.memory_full_info()
    memory = info.uss / 1024. / 1024
    print('{} memory used: {} MB'.format(hint, memory))

###complete graph###
# show_memory_info('Before')
# start=time.time()
# list1=Create_complete_1dmatrix(600)
# # print("One dimentional complete graph is like:",list1)
# shortest_path,pre=floyd(list1)
# # print("The shortest path value from node to other nodes are:",shortest_path,"\nThe previous node from node to other nodes are: ",pre)
# end=time.time()
# time=time=round(end-start,8)
# print("Time used:",time)
# show_memory_info('After')


###sparse graph###
# show_memory_info('Before')
# start1=time.time()
# list2=Create_sparse_1dmatrix(600)
# # print("One dimentional complete graph is like:",list2)
# shortest_path1,pre1=floyd(list2)
# # print("The shortest path value from node to other nodes are:",shortest_path1,"\nThe previous node from node to other nodes are: ",pre1)
# end1=time.time()
# time1=round(end1-start1,8)
# print("Time used:",time1)
# show_memory_info('After')

##test###
def test(s,e,test):# s is start_point, e is end_point
  print("Shortest path between v",s," – v",e,":")
  cost,pre=floyd(test)
  # print(cost)
  print("The distance is:",cost[s-1][e-1])
  pre=pre[s-1]
  path=[]
  i=e-1 # end_point
  while i!=s-1:#start_point
    path.append(i)
    i=pre[i]

  # print(path)

  path_detail="The path is:v"+str(s) #start_point
  for i in path[::-1]:
    path_detail=path_detail+"->v"+str(i+1)
  
  print(path_detail)

### test 1 ###
##I don't know why when using the same matrix, the pre matrix will be reset and no new value
test1_1=test(1,8,test1_1)
test1_2=test(7,8,test1_2)
### teest 2 ###
test2_1=test(2,8,test2_1)
test2_2=test(12,10,test2_2)
