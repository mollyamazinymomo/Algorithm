import math

def floyd(glist):
  n = math.ceil(len(glist*2) ** 0.5)

  path = [[float("inf")] * n for i in range(n)]
  pre=[[0 for i in range(n)]for i in range(n)]
  for i in range(n):
    for j in range(n):
      pre[i][j]=i
  index = 0
  for i in range(n):
    for j in range(i):
      path[i][j] = glist[index]
      path[j][i] = glist[index]
      index += 1
    path[i][i] = 0

  for t in range(n):
    for i in range(n):
      for j in range(n):
        if path[i][j]>path[i][t]+path[t][j]:
          path[i][j]=path[i][t]+path[t][j]
          pre[i][j]=pre[t][j]

  return path,pre