def check(board,row,col):
  i = 0
  while i < row:
    if abs(col-board[i]) in (0, abs(row-i)):
      return False
    i+=1
  return True    

    
def QueenProblems(board,row):
  if row == len(board):
    result.append(list(board))
    return 

  for col in range(len(board)):
    if check(board,row,col):
      board[row] = col
      QueenProblems(board,row+1)
      board[row] = 0
  return False

def generate3d(result):
	answer=set()
	for ans in result:
		point=[]
		for x,y in enumerate(ans):
			tmp=[]
			for z in range(len(board)):
				tmp.append((x,y,z))
			point.append(tmp)

		for a in point[0]:
			for b in point[1]:
				for c in point[2]:
					for d in point[3]:
						answer.add((a,b,c,d))
	return answer

if __name__ == '__main__':
	board=[0 for i in range(8)]
	result=[]
	QueenProblems(board,0)
	ans=generate3d(result)
	print("For 3-D",len(board),"Queen Problem, the number of result is:",len(ans))

#Constraint description:
#No Queen on same colomn, row and diagonal means for 4 Queen Porblem, when 2-D result in 3-D, every Queen has 4 additional place to choose.

  
      

  