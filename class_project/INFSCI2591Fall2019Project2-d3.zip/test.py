inf=float("inf")

test1={
  0:{1:inf,2:inf,3:29,4:inf,5:inf,6:inf,7:inf},
  1:{0:inf,2:inf,3:inf,4:inf,5:11,6:11,7:inf},
  2:{0:inf,1:inf,3:12,4:inf,5:5,6:5,7:inf},
  3:{0:29,1:inf,2:12,4:5,5:inf,6:13,7:inf},
  4:{0:inf,1:inf,2:inf,3:5,5:inf,6:7,7:11},
  5:{0:inf,1:11,2:5,3:inf,4:inf,6:inf,7:17},
  6:{0:inf,1:11,2:5,3:13,4:7,5:inf,7:inf},
  7:{0:inf,1:inf,2:inf,3:inf,4:11,5:17,6:inf}
}

test2={
  0:{1:11,2:14,3:inf,4:8,5:inf,6:29,7:28,8:inf,9:inf,10:14,11:inf},
  1:{0:11,2:12,3:inf,4:6,5:inf,6:inf,7:inf,8:inf,9:inf,10:inf,11:inf},
  2:{0:14,1:12,3:18,4:13,5:13,6:inf,7:inf,8:25,9:inf,10:inf,11:16},
  3:{0:inf,1:inf,2:18,4:inf,5:inf,6:27,7:17,8:9,9:25,10:inf,11:inf},
  4:{0:8,1:6,2:13,3:inf,5:inf,6:inf,7:inf,8:inf,9:inf,10:inf,11:22},
  5:{0:inf,1:inf,2:13,3:inf,4:inf,6:inf,7:15,8:5,9:inf,10:inf,11:inf},
  6:{0:29,1:inf,2:inf,3:27,4:inf,5:inf,7:inf,8:inf,9:inf,10:inf,11:inf},
  7:{0:28,1:inf,2:inf,3:17,4:inf,5:15,6:inf,8:5,9:9,10:inf,11:inf},
  8:{0:inf,1:inf,2:25,3:9,4:inf,5:5,6:inf,7:5,9:inf,10:25,11:inf},
  9:{0:inf,1:inf,2:inf,3:25,4:inf,5:inf,6:inf,7:9,8:inf,10:inf,11:inf},
  10:{0:14,1:inf,2:inf,3:inf,4:inf,5:inf,6:inf,7:inf,8:25,9:inf,11:inf},
  11:{0:inf,1:inf,2:16,3:inf,4:22,5:inf,6:inf,7:inf,8:inf,9:inf,10:inf}
}
