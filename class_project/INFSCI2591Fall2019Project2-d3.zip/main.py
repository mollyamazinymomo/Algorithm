from createajlist import *
from Dijkstra import *
from test import *
import time
import os 
import psutil

def show_memory_info(hint):
    pid = os.getpid()
    p = psutil.Process(pid)

    info = p.memory_full_info()
    memory = info.uss / 1024. / 1024
    print('{} memory used: {} MB'.format(hint, memory))


### ajlist ###

### Complete Graph ###
# show_memory_info('Before')
# start=time.time()
# graph=Create_complete_ajlist(3000)
# # print("AJ List complete graph is like:",graph)
# cost,path=Dijkstra1(0,graph)
# # print("The shortest path values from 0 to other node are:",cost,"\nThe previous node from 0 to other node is: ",path)
# end=time.time()
# time=round(end-start,8)
# print("Time used:",time)
# show_memory_info('After')


### Sparse graph ###
# show_memory_info('Before')
# start1=time.time()
# graph2=Create_sparse_ajlist(3000)
# # print("AJ List sparse graph is like:",graph2)
# cost1,path1=Dijkstra1(0,graph2)
# # print("The shortest path values from 0 to other node are:",cost1,"\nThe previous node from 0 to other node is: ",path1)
# end1=time.time()
# time1=round(end1-start1,8)
# print("Time used:",time1)
# show_memory_info('After')


# ###test###
def test(s,e,test):# s is start_point, e is end_point
  cost,pre=Dijkstra1(s-1,test)
  print("Shortest path between v",s," – v",e,":")
  print("The distance is:",cost[e-1]) #cost here is dictionary
  # print(cost)
  # print(pre)
  path=[]
  i=e-1 # end_point
  while i!=s-1:#start_point
    path.append(i)
    i=pre[i]

  path_detail="The path is:v"+str(s) #start_point
  for i in path[::-1]:
    path_detail=path_detail+"->v"+str(i+1)
  
  print(path_detail)

### test 1 ###
test1_1=test(1,8,test1)
test1_2=test(7,8,test1)
### test 2 ###
test2_1=test(2,8,test2)
test2_2=test(12,10,test2)