def Dijkstra1(start_point,graph):
  
  if graph is None:
    return None

  n=len(graph)
  cost=graph[start_point]
  path=[start_point for i in range(n)]
  book=[0 for i in range(n)]
  book[start_point]=1

  for i in range(n-1):
    u=0
    min_cost=float("inf")
    for j in graph[start_point]:
      if book[j]==0 and graph[start_point][j]<min_cost:
        min_cost=graph[start_point][j]
        u=j
    
    book[u]=1
      
    for k in graph[u]:
      if k != start_point:
        if graph[u][k]<float("inf"):
          if graph[start_point][k]>graph[start_point][u]+graph[u][k]:
            cost[k]=graph[start_point][u]+graph[u][k]
            path[k]=u
  
  return cost,path
  