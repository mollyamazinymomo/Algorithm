
inf=float("inf")
test1_1=[
  [0,inf,inf,29,inf,inf,inf,inf],
  [inf,0,inf,inf,inf,11,11,inf],
  [inf,inf,0,12,inf,5,5,inf],
  [29,inf,12,0,5,inf,13,inf],
  [inf,inf,inf,5,0,inf,7,11],
  [inf,11,5,inf,inf,0,inf,17],
  [inf,11,5,13,7,inf,0,inf],
  [inf,inf,inf,inf,11,17,inf,0]
]

test1_2=[
  [0,inf,inf,29,inf,inf,inf,inf],
  [inf,0,inf,inf,inf,11,11,inf],
  [inf,inf,0,12,inf,5,5,inf],
  [29,inf,12,0,5,inf,13,inf],
  [inf,inf,inf,5,0,inf,7,11],
  [inf,11,5,inf,inf,0,inf,17],
  [inf,11,5,13,7,inf,0,inf],
  [inf,inf,inf,inf,11,17,inf,0]
]



test2_1=[
  [0,11,14,inf,8,inf,29,28,inf,inf,14,inf],
  [11,0,12,inf,6,inf,inf,inf,inf,inf,inf,inf],
  [14,12,0,18,13,13,inf,inf,25,inf,inf,16],
  [inf,inf,18,0,inf,inf,27,17,9,25,inf,inf],
  [8,6,13,inf,0,inf,inf,inf,inf,inf,inf,22],
  [inf,inf,13,inf,inf,0,inf,15,5,inf,inf,inf],
  [29,inf,inf,27,inf,inf,0,inf,inf,inf,inf,inf],
  [28,inf,inf,17,inf,15,inf,0,5,9,inf,inf],
  [inf,inf,25,9,inf,5,inf,5,0,inf,25,inf],
  [inf,inf,inf,25,inf,inf,inf,9,inf,0,inf,inf],
  [14,inf,inf,inf,inf,inf,inf,inf,25,inf,0,inf],
  [inf,inf,16,inf,22,inf,inf,inf,inf,inf,inf,0]
]


test2_2=[
  [0,11,14,inf,8,inf,29,28,inf,inf,14,inf],
  [11,0,12,inf,6,inf,inf,inf,inf,inf,inf,inf],
  [14,12,0,18,13,13,inf,inf,25,inf,inf,16],
  [inf,inf,18,0,inf,inf,27,17,9,25,inf,inf],
  [8,6,13,inf,0,inf,inf,inf,inf,inf,inf,22],
  [inf,inf,13,inf,inf,0,inf,15,5,inf,inf,inf],
  [29,inf,inf,27,inf,inf,0,inf,inf,inf,inf,inf],
  [28,inf,inf,17,inf,15,inf,0,5,9,inf,inf],
  [inf,inf,25,9,inf,5,inf,5,0,inf,25,inf],
  [inf,inf,inf,25,inf,inf,inf,9,inf,0,inf,inf],
  [14,inf,inf,inf,inf,inf,inf,inf,25,inf,0,inf],
  [inf,inf,16,inf,22,inf,inf,inf,inf,inf,inf,0]
]