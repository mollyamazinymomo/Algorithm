from create2dmatrix import *
from Floyd import *
from test import *
import time
import os 
import psutil


def show_memory_info(hint):
    pid = os.getpid()
    p = psutil.Process(pid)

    info = p.memory_full_info()
    memory = info.uss / 1024. / 1024
    print('{} memory used: {} MB'.format(hint, memory))


### 2-dimentional ###

### Complete Graph ###
# show_memory_info('Before')
# start=time.time()
# matrix3=Create_complete_2dmatrix(10)
# print("Two dimentional complete graph is like:",matrix3)
# shortest_path,pre=Floyd(matrix3)
# print("The shortest path value from node to other nodes are:",shortest_path,"\nThe previous node from node to other nodes are: ",pre)
# end=time.time()
# time=round(end-start,8)
# print(time)
# show_memory_info('After')


### Sparse Graph ###
# show_memory_info('Before')
# start=time.time()
# matrix4=Create_sparse_2dmatrix(600)
# # print("Two dimentional sparse graph is like:",matrix4)
# shortest_path1,pre1=Floyd(matrix4)
# # print("The shortest path value from node to other nodes are:",shortest_path1,"\nThe previous node from node to other nodes are: ",pre1)
# end=time.time()
# time=round(end-start,8)
# print(time)
# show_memory_info('After')

###test###
def test(s,e,test):# s is start_point, e is end_point
  print("Shortest path between v",s," – v",e,":")
  cost,pre=Floyd(test)
  # print(cost)
  print("The distance is:",cost[s-1][e-1])
  pre=pre[s-1]
  path=[]
  i=e-1 # end_point
  while i!=s-1:#start_point
    path.append(i)
    i=pre[i]

  # print(path)

  path_detail="The path is:v"+str(s) #start_point
  for i in path[::-1]:
    path_detail=path_detail+"->v"+str(i+1)
  
  print(path_detail)

### test 1 ###
##I don't know why when using the same matrix, the pre matrix will be reset and no new value
test1_1=test(1,8,test1_1)
test1_2=test(7,8,test1_2)
### teest 2 ###
test2_1=test(2,8,test2_1)
test2_2=test(12,10,test2_2)
