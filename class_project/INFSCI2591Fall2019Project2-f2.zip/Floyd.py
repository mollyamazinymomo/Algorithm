def Floyd(matrix):
  original_pd=matrix
  n=len(original_pd)
  pre=[[0 for i in range(n)]for i in range(n)]
  for i in range(n):
    for j in range(n):
      pre[i][j]=i
  
  for t in range(n):
    for i in range(n):
      for j in range(n):
        if original_pd[i][j]>original_pd[i][t]+original_pd[t][j]:
          original_pd[i][j]=original_pd[i][t]+original_pd[t][j]
          pre[i][j]=pre[t][j]
  
  return original_pd,pre