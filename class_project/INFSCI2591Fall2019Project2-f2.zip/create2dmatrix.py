import random

class Generate_2dm:
  # define Construction method for this class
  def __init__(self,data):
    self.data=data
    self.matrix=[[float("inf") for i in range(self.data)]for j in range(self.data)]

  def get_matrix(self):
    return self.matrix

# If no parameter was given, need to add self to parameter
# If have parameter, put them after self
# Use two different static method to design different kind of the same class graph
  def complete_2dm(self):
    for i in range(0,self.data):
      for j in range(i,self.data):
        if i==j:
          self.matrix[i][j]=0
        else:
          self.matrix[i][j]=random.randint(1,1000)
          self.matrix[j][i]=self.matrix[i][j]

  def sparse_2dm(self):
    for i in range(0,self.data):
      j=0
      j=i
      self.matrix[i][j]=0
    for i in range(0,self.data-1):
      location=0;
      location=random.randint(i+1,self.data-1)
      self.matrix[i][location]=random.randint(1,1000)
      self.matrix[location][i]=self.matrix[i][location]

def Create_complete_2dmatrix(n):
  matrix1=Generate_2dm(n)
  matrix1.complete_2dm()
  matrix=matrix1.get_matrix()
  return matrix

def Create_sparse_2dmatrix(n):
  matrix2=Generate_2dm(n)
  matrix2.sparse_2dm()
  matrix=matrix2.get_matrix()
  return matrix
