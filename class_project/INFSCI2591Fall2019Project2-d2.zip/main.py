from create2dmatrix import *
from Dijkstra import *
from test import *
# from Floyd import *
import time
import os 
import psutil

def show_memory_info(hint):
    pid = os.getpid()
    p = psutil.Process(pid)

    info = p.memory_full_info()
    memory = info.uss / 1024. / 1024
    print('{} memory used: {} MB'.format(hint, memory))

### complete graph ###
# show_memory_info('Before')
# start=time.time()
# matrix3=Create_complete_2dmatrix(20)
# # print("Two dimentional complete graph is like:",matrix3)
# shortest_path,path=Dijkstra(1,matrix3)
# # print("The shortest path value from 0 to other point is",shortest_path,"\nThe previous node from 0 to other node is: ",path)
# end=time.time()
# time=round(end-start,8)
# print("Time used:",time)
# show_memory_info('After')

### sparse graph ###
# show_memory_info('Before')
# start=time.time()
# matrix4=Create_sparse_2dmatrix(6000)
# # print("Two dimentional sparse graph is like:",matrix4)
# shortest_path1,path1=Dijkstra(0,matrix4)
# # print("The shortest path from 0 to other point is",shortest_path1,"\nThe previous node from 0 to other node is:",path1)
# end=time.time()
# time=round(end-start,8)
# print("Time used:",time)
# show_memory_info('After')

###test###
def test(s,e,test):# s is start_point, e is end_point
  cost,pre=Dijkstra(s-1,test)
  # print(cost)
  print("Shortest path between v",s," – v",e,":")
  print("The distance is:",cost[e-1])
  path=[]
  i=e-1 # end_point
  while i!=s-1:#start_point
    path.append(i)
    i=pre[i]

  path_detail="The path is:v"+str(s) #start_point
  for i in path[::-1]:
    path_detail=path_detail+"->v"+str(i+1)
  
  print(path_detail)

### test 1 ###
test1_1=test(1,8,test1)
test1_2=test(7,8,test1)
### teest 2 ###
test2_1=test(2,8,test2)
test2_2=test(12,10,test2)




