#此函数适用于无向加权稀疏图，完全图，及有向图求Dijkstra最短路径
def Dijkstra(start_point,matrix):
  original_pd=[]
  n=len(matrix)

  path=[start_point for i in range(n)]

  book=[0 for i in range(n)]
  # here first put th start point in book as 1
  book[start_point]=1
  s=start_point
  for j in range(0,n):
    original_pd.append(matrix[s][j])
  
  for i in range(0,n-1):
    minimum=float("inf")
    u=0
    #此for循环是从没有被标记过的点即book[j]中找一个距离startpoint最近的点
    for j in range(0,n):
      if book[j]==0 and original_pd[j]<minimum:
        minimum=original_pd[j]
        u=j
    #book[u]=1表示：当前u点作为中转点，进行标记，下次不再选择u点作为中转点
    book[u]=1

    for k in range(0,n):
      # 如果matrix[u][k]等于∞，说明k点不能通过u点中转到startpoint，所以就不考虑中转减距的情况
      if matrix[u][k]<float("inf"):
        #original_pd[k]为startpoint到k的直接距离，original_pd[u]+matrix[u][k]为startpoint到k从u点中转的距离
        if original_pd[k]>original_pd[u]+matrix[u][k]:
          original_pd[k]=original_pd[u]+matrix[u][k]
          path[k]=u
  #返回的是从startpoint到其他点的最短距离
  return original_pd,path

###since better understand the code I write, so some use Chinese to comment###
