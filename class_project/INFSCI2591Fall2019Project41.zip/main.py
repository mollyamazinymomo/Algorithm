import random
import time
import math
import matplotlib.pyplot as plt
import numpy as np

def partition(arr,l,h):
	i=(l-1)
	x=arr[h]

	for j in range(l,h):
		if arr[j]<=x:
			i=i+1
			arr[i],arr[j]=arr[j],arr[i]
		
	arr[i+1],arr[h]=arr[h],arr[i+1]
	return (i+1)

def IterativeQuickSort(arr,l,h):
	size=h-l+1
	stack=[0]*(size)
	top=-1

	top=top+1
	stack[top]=l
	top=top+1
	stack[top]=h

	while top>=0:
		h=stack[top]
		top=top-1
		l=stack[top]
		top=top-1

		p=partition(arr,l,h)

		if p-1>l:
			top=top+1
			stack[top]=l
			top=top+1
			stack[top]=p-1

		if p+1<h:
			top=top+1
			stack[top]=p+1
			top=top+1
			stack[top]=h	

def BinarySearch(o_arr,arr,d_num):
	# print(arr)
	low=0
	high=len(arr)-1
	while low<=high: ##Here use <= to make sure we have distribute to the final single number
		mid=int((low+high)/2)
		if arr[mid]<d_num:
			low=mid+1
			# print(low)
		elif arr[mid]>d_num:
			high=mid-1
			# print(high)
		else:
			return [arr[mid],list(o_arr).index(arr[mid])] 

	return [-1,'Number not Found']

def InterpolationSearch(o_arr,arr,d_num):
	low=0
	high=len(arr)-1
	times=0
	while low<=high:
		times=times+1
		mid=low+int((high-low)*(d_num-arr[low])/(arr[high]-arr[low]))
		if arr[mid]<d_num:
			low=mid+1
		elif arr[mid]>d_num:
			high=mid-1
		else:
			return[arr[mid],list(o_arr).index(arr[mid])]
	
	return [-1,'Number not Found']

def RobustInterpolationSearch(o_arr,arr,d_num):
	low=0
	high=len(arr)-1
	if arr[low]<=d_num and d_num<=arr[high]:
		while low<=high:
			d=arr[high]-arr[low]
			gap=int((high-low)**0.5)
			if d==0:
				mid=low
			else:
				mid=low+((d_num-arr[low])*(high-low))//d
				mid = min(high-gap,max(mid,low+gap))
			if d_num==arr[mid]:
				return [arr[mid],list(o_arr).index(arr[mid])]
			elif d_num<arr[mid]:
				high=mid-1
			else:
				low=mid+1

	return [-1,'Number not Found']

##Test##
# choice=input("See BinarySearch working case:\n1.Worst Case\n2.Best Case\n3.Average Case\n\nSee InterpolatioSearch work case:\n4.Worst Case\n5.Best Case\n6.Average Case\n\nSee RobustInterpolatioSearch work case:\n7.Worst Case\n8.Best Case\n9.Average Case\n\nYour choice: ")
# choice=int(choice)


def testing(choice,n,arr):

	##BinarySearch Worst case##
	if choice==1:
		o_arr=arr
		IterativeQuickSort(arr,0,len(arr)-1)
		num=arr[n-1]

		start=time.time()
		x=BinarySearch(o_arr,arr,num)
		end=time.time()
		time_used=round(end-start,16)

		if x[0]==-1:
			print('Does not found this number')
		else:
			print('Number:',x[0],'has been found at list index:',x[1],'\nTime use:',time_used)
		return time_used

	##BinarySearch Best Case##
	elif choice==2:
		o_arr=arr
		IterativeQuickSort(arr,0,len(arr)-1)
		num=arr[int(len(arr)/2)-1]

		start=time.time()
		x=BinarySearch(o_arr,arr,num)
		end=time.time()
		time_used=round(end-start,16)

		if x[0]==-1:
			print('Does not found this number')
		else:
			print('Number:',x[0],'has been found at list index:',x[1],'\nTime use:',time_used)
		return time_used

	##BinarySearch Average Case##
	elif choice==3:
		o_arr=arr
		time1=[]
		IterativeQuickSort(arr,0,len(arr)-1)
		for i in range(len(arr)-1):
			num=arr[i]
			start=time.time()
			x=BinarySearch(o_arr,arr,num)
			end=time.time()
			time_used=round(end-start,16)
			time1.append(time_used)

		average_t=sum(time1)/len(time1)
		print('Average time use:',average_t)
		return average_t

	##InterpolatioSearch Worst case##
	elif choice==4:
		o_arr=arr
		IterativeQuickSort(arr,0,len(arr)-1)
		num=arr[n-1]

		start=time.time()
		x=InterpolationSearch(o_arr,arr,num)
		end=time.time()
		time_used=round(end-start,16)

		if x[0]==-1:
			print('Does not found this number')
		else:
			print('Number:',x[0],'has been found at list index:',x[1],'\nTime use:',time_used)
		return time_used

	##InterpolatioSearch Best case##
	elif choice==5:
		o_arr=arr
		IterativeQuickSort(arr,0,len(arr)-1)
		num=arr[int(len(arr)/2)-1]

		start=time.time()
		x=InterpolationSearch(o_arr,arr,num)
		end=time.time()
		time_used=round(end-start,16)

		if x[0]==-1:
			print('Does not found this number')
		else:
			print('Number:',x[0],'has been found at list index:',x[1],'\nTime use:',time_used)
		return time_used

	##InterpolatioSearch Average case##
	elif choice==6:
		o_arr=arr
		time1=[]
		IterativeQuickSort(arr,0,len(arr)-1)

		for i in range(len(arr)-1):
			num=arr[i]
			start=time.time()
			x=InterpolationSearch(o_arr,arr,num)
			end=time.time()
			time_used=round(end-start,16)
			time1.append(time_used)

		average_t=sum(time1)/len(time1)
		print('Average time use:',average_t)
		return average_t

	##Robust InterpolatioSearch Worst case##
	elif choice==7:
		o_arr=arr
		IterativeQuickSort(arr,0,len(arr)-1)
		num=arr[n-1]

		start=time.time()
		x=RobustInterpolationSearch(o_arr,arr,num)
		end=time.time()
		time_used=round(end-start,16)

		if x[0]==-1:
			print('Does not found this number')
		else:
			print('Number:',x[0],'has been found at list index:',x[1],'\nTime use:',time_used)
		return time_used
	
	##Robust InterpolatioSearch Best case##
	elif choice==8:
		o_arr=arr
		IterativeQuickSort(arr,0,len(arr)-1)
		num=arr[0+(len(arr)-1-0)//2]

		start=time.time()
		x=RobustInterpolationSearch(o_arr,arr,num)
		end=time.time()
		time_used=round(end-start,16)

		if x[0]==-1:
			print('Does not found this number')
		else:
			print('Number:',x[0],'has been found at list index:',x[1],'\nTime use:',time_used)
		return time_used

	##Robust InterpolatioSearch Average case##
	elif choice==9:
		o_arr=arr
		time1=[]
		IterativeQuickSort(arr,0,len(arr)-1)

		for i in range(len(arr)-1):
			num=arr[i]
			start=time.time()
			x=RobustInterpolationSearch(o_arr,arr,num)
			end=time.time()
			time_used=round(end-start,16)
			time1.append(time_used)

		average_t=sum(time1)/len(time1)
		print('Average time use:',average_t)
		return average_t

timeall=[]
for i in range(1,10):
	choice=i
	for j in range(10000,70000,10000):
		n=j
		arr=random.sample(range(60000),n)
		time_used=testing(choice,n,arr)
		timeall.append(time_used)
	# print(timeall)

x=[10000,20000,30000,40000,50000,60000]
timearray=np.array(timeall).reshape(9,6)
print(timearray)

##Draw plot
figure=plt.figure(num=3, figsize=(15, 8),dpi=80)
ax1 = figure.add_subplot(221)  
ax2 = figure.add_subplot(222)
ax3 = figure.add_subplot(223)
ax1.plot(x,timearray[0],label='Worst Case')
ax1.plot(x,timearray[1],label='Best Case')
ax1.plot(x,timearray[2],label='Average Case')
ax1.legend(title='Time Complexity Analysis')
ax1.set_title("BinarySearch")
ax1.set_ylabel("Time/s")
ax1.set_xlabel("Numbers")

ax2.plot(x,timearray[3],label='Worst Case')
ax2.plot(x,timearray[4],label='Best Case')
ax2.plot(x,timearray[5],label='Average Case')
ax2.legend(title='Time Complexity Analysis')
ax2.set_title("InterpolationSearch")
ax2.set_ylabel("Time/s")
ax2.set_xlabel("Numbers")

ax3.plot(x,timearray[6],label='Worst Case')
ax3.plot(x,timearray[7],label='Best Case')
ax3.plot(x,timearray[8],label='Average Case')
ax3.legend(title='Time Complexity Analysis')
ax3.set_title("RobustInterpolationSearch")
ax3.set_ylabel("Time/s")
ax3.set_xlabel("Numbers")

plt.savefig("SearchAlgorithmComparision1.png")


