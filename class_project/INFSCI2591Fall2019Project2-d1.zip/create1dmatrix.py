import random

### 1-dimentional ###
class Generate_1dm:

  def __init__(self,data):
    self.data=data
    self.matrix=[[float("inf") for i in range(self.data)]for j in range(self.data)]
    self.mtolist=[]
  
  def get_mtolist(self):
    return self.mtolist

  def complete_1dm(self):
    for i in range(0,self.data):
      for j in range(i+1,self.data):
        self.matrix[i][j]=random.randint(1,1000)
    # print(self.matrix)
    #下三角
    for i in range(1,self.data):
      for j in range(0,i):
        self.mtolist.append(self.matrix[j][i])
  
  def sparse_1dm(self):
    for i in range(0,self.data-1):
      location=0;
      location=random.randint(i+1,self.data-1)
      self.matrix[i][location]=random.randint(1,1000)
    # print(self.matrix)
    
    for i in range(1,self.data):
      for j in range(0,i):
        self.mtolist.append(self.matrix[j][i])

def Create_complete_1dmatrix(n):
  matrix1=Generate_1dm(n)
  matrix1.complete_1dm()
  list1=matrix1.get_mtolist()
  return list1

def Create_sparse_1dmatrix(n):
  matrix2=Generate_1dm(n)
  matrix2.sparse_1dm()
  list1=matrix2.get_mtolist()
  return list1