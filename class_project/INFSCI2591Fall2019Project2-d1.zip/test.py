inf=float("inf")

test1=[inf,inf,inf,29,inf,12,inf,inf,inf,5,inf,11,5,inf,inf,inf,11,5,13,7,inf,inf,inf,inf,inf,11,17,inf]

test2=[11,14,12,inf,inf,18,8,6,13,inf,inf,inf,13,inf,inf,29,inf,inf,27,inf,inf,28,inf,inf,17,inf,15,inf,inf,inf,25,9,inf,5,inf,5,inf,inf,inf,25,inf,inf,inf,9,inf,14,inf,inf,inf,inf,inf,inf,inf,25,inf,inf,inf,16,inf,22,inf,inf,inf,inf,inf,inf]