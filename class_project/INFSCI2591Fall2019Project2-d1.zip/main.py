from create1dmatrix import *
from Dijkstra import *
from test import *
import time
import os 
import psutil


def show_memory_info(hint):
    pid = os.getpid()
    p = psutil.Process(pid)

    info = p.memory_full_info()
    memory = info.uss / 1024. / 1024
    print('{} memory used: {} MB'.format(hint, memory))

### complete graph ###
# show_memory_info('Before')
# start=time.time()
# list1=Create_complete_1dmatrix(6000)
# # print("One dimentional complete graph is like:",list1)
# sp=dijkstra(list1,0,5999)
# # print("The shortest path value from 0 to the final point is",sp[0],"\nThe path is:",sp[1])
# end=time.time()
# time=round(end-start,8)
# print("Time used:",time)
# show_memory_info('After')


###sparse graph###
# show_memory_info('Before')
# start1=time.time()
# list2=Create_sparse_1dmatrix(6000)
# # print("One dimentional complete graph is like:",list2)
# sp1=dijkstra(list2,0,5999)
# # print("The shortest path value from 0 to the final point is",sp1[0],"\nThe path is:",sp1[1])
# end1=time.time()
# time1=round(end1-start1,8)
# print("Time used:",time1)
# show_memory_info('After')


##test###
def test_detail(path_list):
  detail="The path is: "
  for i in range(len(path_list)):
    if i!=len(path_list)-1:
      detail+="v"+str(path_list[i]+1)+"->"
    else:
      detail+="v"+str(path_list[i]+1)
  return detail
###test1###
test1_1=dijkstra(test1,0,7)
print("Shortest path between v 1  – v 8 :\nThe distance is: ",test1_1[0])
print(test_detail(test1_1[1]))

test1_2=dijkstra(test1,6,7)
print("Shortest path between v 7  – v 8 :\nThe distance is: ",test1_2[0])
print(test_detail(test1_2[1]))

###test2###
test2_1=dijkstra(test2,1,7)
print("Shortest path between v 2  – v 8 :\nThe distance is: ",test2_1[0])
print(test_detail(test2_1[1]))

def Reverse(lst): 
  return [ele for ele in reversed(lst)]

test2_2=dijkstra(test2,11,9)
##if start_point > end_point###
path=[]
for i in test2_2[1]:
  path.append(i)

print("Shortest path between v 12  – v 10 :\nThe distance is: ",test2_2[0])
print(test_detail(Reverse(path)))