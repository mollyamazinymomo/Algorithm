from itertools import combinations
from heapq import *
import math

def transform_index(i,j):
  return  (i - 1) * i // 2 + j
    
def get_index(node,num_nodes):
  rect = []
  for j in range(node):
    rect.append((j,transform_index(node,j)))

  for i in range(node+1,num_nodes):
    rect.append((i,transform_index(i,node)))

  return rect

def dijkstra(glist,start,end):
  if start>end:
    mid=start
    start=end
    end=mid
  
  n = math.ceil(len(glist*2) ** 0.5)

  q=[(0,start,[])]
  visited=set()
  mins={start:0}
  heapify(q)

  while q:
    (min_d,i,path) = heappop(q)

    if i not in visited:
      visited.add(i)
      path = path + [i]
 
      if i == end: 
        return (min_d,path)
      
      for j,distance in ((j, glist[index]) for j,index in get_index(i,n)):
        if j in visited or distance == float("inf"): 
          continue
        prev = mins.get(j,float("inf"))
        new_min_d = min_d + distance
        if prev > new_min_d:
          mins[j] = new_min_d
          heappush(q,(new_min_d,j,path))      
    
  return float("inf")